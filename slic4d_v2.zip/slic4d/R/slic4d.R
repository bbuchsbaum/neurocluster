
#' Fast 4D SLIC supervoxels (mask-aware, gradient relocation)
#'
#' Cluster a 4D \code{NeuroVec} (x,y,z,time) into compact, spatially contiguous
#' 3D supervoxels using SLIC extended to time-series features. This version adds:
#' \itemize{
#'   \item mask-aware seeding (grid+farthest or Poisson in-mask)
#'   \item gradient-based seed relocation (intensity or time-series correlation)
#'   \item strict connectivity via 6/26-neighbor BFS
#' }
#'
#' @param bvec A \code{NeuroVec} with dims (X, Y, Z, T).
#' @param mask A 3D \code{NeuroVol} (or logical array) indicating voxels to include.
#' @param K Target number of supervoxels.
#' @param compactness Spatial vs feature tradeoff (like SLIC 'm'). Larger = more compact.
#' @param max_iter Maximum iterations (default 10).
#' @param n_threads Number of CPU threads to use (0 = auto).
#' @param step_mm Optional approximate spacing between seeds in millimeters; if NULL,
#'   computed as cubic root of bounding-box volume / K (within mask).
#' @param n_components If > 0, random-project each voxel's time series to this dimension
#'   for speed (Johnson-Lindenstrauss style). 0 = use full time series.
#' @param feature_norm One of "zscale", "l2", "none".
#' @param seed_method One of c("grid", "mask_grid", "mask_poisson", "farthest").
#' @param seed_relocate One of c("none","intensity","correlation","spatial").
#' @param seed_relocate_radius Neighborhood (in voxels) for relocation search; default 1 (3x3x3).
#' @param connectivity Neighborhood for connectivity enforcement: 6 or 26.
#' @param strict_connectivity Ensure one connected component per label (default TRUE).
#' @param enforce_connectivity Backward-compat boolean; if TRUE, strict connectivity is used.
#' @param min_size Minimum component size (voxels) for merges (default 0 = auto from step).
#' @param verbose Logical.
#'
#' @return A list of class \code{cluster_result} with elements:
#' \itemize{
#'   \item \code{clusvol}: \code{ClusteredNeuroVol} with the final labels
#'   \item \code{cluster}: integer vector of length = #masked voxels (1..K)
#'   \item \code{centers}: matrix (K x d_feat) center features
#'   \item \code{coord_centers}: matrix (K x 3) spatial centers in mm
#' }
#' @export
slic4d_supervoxels <- function(bvec, mask,
                               K,
                               compactness = 10,
                               max_iter = 10,
                               n_threads = 0,
                               step_mm = NULL,
                               n_components = 0,
                               feature_norm = c("zscale", "l2", "none"),
                               seed_method = c("mask_grid","grid","mask_poisson","farthest"),
                               seed_relocate = c("correlation","intensity","spatial","none"),
                               seed_relocate_radius = 1L,
                               connectivity = c(26L,6L),
                               strict_connectivity = TRUE,
                               enforce_connectivity = TRUE,
                               min_size = 0L,
                               verbose = FALSE) {
  feature_norm <- match.arg(feature_norm)
  seed_method  <- match.arg(seed_method)
  seed_relocate <- match.arg(seed_relocate)
  connectivity <- as.integer(match.arg(as.character(connectivity), c("26","6")))

  stopifnot(inherits(bvec, "NeuroVec"))
  if (inherits(mask, "NeuroVol")) {
    mask_arr <- as.logical(mask)
    sp <- neuroim2::space(mask)
  } else {
    mask_arr <- as.logical(mask)
    sp <- neuroim2::space(neuroim2::vol(mask_arr))
  }

  mask_idx <- which(mask_arr)
  if (length(mask_idx) == 0) stop("Mask is empty")

  # dims & spacing
  dims <- dim(mask_arr)
  voxmm <- neuroim2::voxdim(sp)  # c(dx,dy,dz) in mm

  # Spatial coordinates (mm) for masked voxels
  coords <- neuroim2::index_to_coord(sp, mask_idx)
  coords <- as.matrix(coords)  # N x 3

  # Feature matrix: voxel time series (N x T)
  feat <- neuroim2::series(bvec, mask_idx)
  feat <- as.matrix(feat)

  # Optional feature normalization
  if (feature_norm == "zscale") {
    mu <- colMeans(feat)
    sdv <- apply(feat, 2, sd)
    sdv[sdv == 0] <- 1
    feat <- sweep(sweep(feat, 2, mu, "-"), 2, sdv, "/")
  } else if (feature_norm == "l2") {
    nrm <- sqrt(rowSums(feat * feat))
    nrm[nrm == 0] <- 1
    feat <- feat / nrm
  }

  # Optional random projection for speed
  if (n_components > 0 && n_components < ncol(feat)) {
    set.seed(123)
    R <- matrix(rnorm(ncol(feat) * n_components) / sqrt(n_components), nrow = ncol(feat), ncol = n_components)
    feat <- feat %*% R  # N x n_components
  }

  # Compute default step from mask bbox volume / K if not supplied
  if (is.null(step_mm)) {
    mins <- apply(coords, 2, min)
    maxs <- apply(coords, 2, max)
    vol  <- prod(pmax(1e-6, maxs - mins))
    step_mm <- (vol / K)^(1/3)
  }

  # Optional gradient-based seed relocation: precompute gradient scalar vol
  grad_masked <- numeric(0)
  if (seed_relocate != "none") {
    if (seed_relocate == "correlation") {
      # Use the user's correlation_gradient_cpp (expects full 4D array + 3D mask)
      img4d <- as.array(bvec)
      grad3d <- correlation_gradient_cpp(img4d, as.numeric(mask_arr))
      dim(grad3d) <- dims
      grad_masked <- grad3d[mask_idx]
    } else if (seed_relocate == "intensity") {
      # Mean over time then central-diff gradient magnitude
      img4d <- as.array(bvec)
      mean3d <- apply(img4d, c(1,2,3), mean)
      grad3d <- .grad3d_fdiff(mean3d)
      grad_masked <- grad3d[mask_idx]
    } else if (seed_relocate == "spatial") {
      # Use existing spatial gradient (neighborweights based)
      if (!requireNamespace("neighborweights", quietly = TRUE)) {
        warning("neighborweights not installed; falling back to intensity gradient")
        img4d <- as.array(bvec); mean3d <- apply(img4d, c(1,2,3), mean)
        grad3d <- .grad3d_fdiff(mean3d)
      } else {
        # spatial_gradient() defined in R/gradient.R (provided)
        grad3d <- spatial_gradient(neuroim2::vol(apply(as.array(bvec), c(1,2,3), mean), space=sp), neuroim2::vol(mask_arr, space=sp))
        # spatial_gradient may return a NeuroVol or array; coerce to array
        if (inherits(grad3d, "NeuroVol")) grad3d <- as.array(grad3d)
      }
      grad_masked <- grad3d[mask_idx]
    }
  }

  # Run core
  core <- slic4d_core(feat, coords,
                      mask_lin_idx = as.integer(mask_idx) - 1L,  # 0-based for C++
                      dims = as.integer(dims),
                      voxmm = as.numeric(voxmm),
                      K = as.integer(K),
                      compactness = as.numeric(compactness),
                      max_iter = as.integer(max_iter),
                      step_mm = as.numeric(step_mm),
                      n_threads = as.integer(n_threads),
                      seed_method = seed_method,
                      enforce_connectivity = isTRUE(enforce_connectivity) || isTRUE(strict_connectivity),
                      min_size = as.integer(min_size),
                      connectivity = as.integer(connectivity),
                      strict_connectivity = isTRUE(strict_connectivity),
                      grad_masked = as.numeric(grad_masked),
                      seed_relocate_radius = as.integer(seed_relocate_radius),
                      verbose = verbose)

  # Build ClusteredNeuroVol consistent with your supervoxels.R
  kvol <- ClusteredNeuroVol(mask_arr, clusters = core$labels)

  structure(list(
    clusvol       = kvol,
    cluster       = core$labels,
    centers       = core$center_feats,
    coord_centers = core$center_coords
  ), class = c("cluster_result", "list"))
}

# Fast finite-difference 3D gradient magnitude
.grad3d_fdiff <- function(arr) {
  dx <- arr * 0; dy <- dx; dz <- dx
  dx[-1,,] <- arr[-1,,] - arr[-nrow(arr),,]
  dy[,-1,] <- arr[,-1,] - arr[,-ncol(arr),]
  dz[,,-1] <- arr[,,-1] - arr[,,-dim(arr)[3]]
  sqrt(dx*dx + dy*dy + dz*dz)
}

#' Compute a summary gradient volume (for troubleshooting/visualization)
#' @export
slic4d_grad_summary <- function(bvec, mask, method=c("correlation","intensity","spatial")) {
  method <- match.arg(method)
  if (method=="correlation") {
    img4d <- as.array(bvec)
    grad3d <- correlation_gradient_cpp(img4d, as.numeric(as.logical(mask)))
    dim(grad3d) <- neuroim2::dim(mask)
    return(grad3d)
  } else if (method=="intensity") {
    img4d <- as.array(bvec)
    mean3d <- apply(img4d, c(1,2,3), mean)
    return(.grad3d_fdiff(mean3d))
  } else {
    if (!requireNamespace("neighborweights", quietly = TRUE))
      stop("neighborweights not installed for 'spatial' method.")
    spatial_gradient(neuroim2::vol(apply(as.array(bvec), c(1,2,3), mean), space=neuroim2::space(mask)),
                     neuroim2::vol(as.logical(mask), space=neuroim2::space(mask)))
  }
}
