
// [[Rcpp::plugins(cpp17)]]
#include <Rcpp.h>
#include <RcppParallel.h>
#include <unordered_map>
#include <unordered_set>
#include <cmath>
#include <algorithm>
#include <limits>
#include <random>

using namespace Rcpp;
using namespace RcppParallel;

// Hash for linear index -> masked index map
struct IntHash {
  std::size_t operator()(const int &x) const noexcept { return std::hash<int>()(x); }
};

// Convert 0-based linear -> (i,j,k) for R-style column-major dims (X,Y,Z)
inline void lin_to_ijk(int lin, const IntegerVector& dims, int &i, int &j, int &k) {
  int nx = dims[0], ny = dims[1];
  i = lin % nx;
  int tmp = lin / nx;
  j = tmp % ny;
  k = tmp / ny;
}

inline int ijk_to_lin(int i, int j, int k, const IntegerVector& dims) {
  return i + j * dims[0] + k * dims[0] * dims[1];
}

// Neighborhood offsets for 6 and 26
static std::vector<std::array<int,3>> make_offsets6() {
  return {{ {1,0,0}, {-1,0,0}, {0,1,0}, {0,-1,0}, {0,0,1}, {0,0,-1} }};
}
static std::vector<std::array<int,3>> make_offsets26() {
  std::vector<std::array<int,3>> off;
  for (int dz=-1; dz<=1; ++dz) for (int dy=-1; dy<=1; ++dy) for (int dx=-1; dx<=1; ++dx) {
    if (dx==0 && dy==0 && dz==0) continue;
    off.push_back({dx,dy,dz});
  }
  return off;
}

// ----- Grid index for centers (3D spatial hash) -----
struct GridIndex {
  std::vector<int> first;
  std::vector<int> next;
  int nx, ny, nz;
  double step;     // cell size (we use ~ 2*step_mm)
  NumericMatrix center_coords;
  NumericVector mins; // 3

  GridIndex(int nx_, int ny_, int nz_, double cellStep,
            NumericMatrix center_coords_, NumericVector mins_)
    : nx(nx_), ny(ny_), nz(nz_), step(cellStep), center_coords(center_coords_), mins(mins_) {}

  inline int cell_of_center(const int k) const {
    double x = center_coords(k, 0);
    double y = center_coords(k, 1);
    double z = center_coords(k, 2);
    int gx = std::max(0, std::min(nx-1, (int)std::floor((x - mins[0]) / step)));
    int gy = std::max(0, std::min(ny-1, (int)std::floor((y - mins[1]) / step)));
    int gz = std::max(0, std::min(nz-1, (int)std::floor((z - mins[2]) / step)));
    return gx + nx * (gy + ny * gz);
  }

  inline int cell_of_point(const double x, const double y, const double z) const {
    int gx = std::max(0, std::min(nx-1, (int)std::floor((x - mins[0]) / step)));
    int gy = std::max(0, std::min(ny-1, (int)std::floor((y - mins[1]) / step)));
    int gz = std::max(0, std::min(nz-1, (int)std::floor((z - mins[2]) / step)));
    return gx + nx * (gy + ny * gz);
  }
};

// Assignment worker
struct AssignWorker : public Worker {
  RMatrix<double> feats;      // N x F
  RMatrix<double> coords;     // N x 3
  RMatrix<double> center_feats;  // K x F
  RMatrix<double> center_coords; // K x 3
  GridIndex &gindex;
  double compact2;
  double step_mm;
  RVector<int> labels;             // length N
  RVector<double> dists;           // length N
  AssignWorker(NumericMatrix feats_,
               NumericMatrix coords_,
               NumericMatrix center_feats_,
               NumericMatrix center_coords_,
               GridIndex &gindex_,
               double compactness,
               double step_mm_,
               IntegerVector labels_,
               NumericVector dists_)
    : feats(feats_), coords(coords_),
      center_feats(center_feats_), center_coords(center_coords_),
      gindex(gindex_), compact2(compactness*compactness), step_mm(step_mm_),
      labels(labels_), dists(dists_) {}
  void operator()(std::size_t begin, std::size_t end) {
    int F = feats.ncol();
    int nx = gindex.nx, ny = gindex.ny, nz = gindex.nz;
    for (std::size_t i = begin; i < end; ++i) {
      double xi = coords(i,0), yi = coords(i,1), zi = coords(i,2);
      int c = gindex.cell_of_point(xi, yi, zi);
      int gz = c / (nx*ny);
      int gy = (c - gz*nx*ny) / nx;
      int gx = c - gz*nx*ny - gy*nx;
      double best = dists[i];
      int bestk = labels[i];
      for (int dz = -1; dz <= 1; ++dz) {
        int cz = gz + dz; if (cz < 0 || cz >= nz) continue;
        for (int dy = -1; dy <= 1; ++dy) {
          int cy = gy + dy; if (cy < 0 || cy >= ny) continue;
          for (int dx = -1; dx <= 1; ++dx) {
            int cx = gx + dx; if (cx < 0 || cx >= nx) continue;
            int cellIndex = cx + nx * (cy + ny * cz);
            int k = gindex.first[cellIndex];
            while (k != -1) {
              double df2 = 0.0;
              for (int f = 0; f < F; ++f) {
                double d = feats(i,f) - center_feats(k,f);
                df2 += d*d;
              }
              double dxs = xi - center_coords(k,0);
              double dys = yi - center_coords(k,1);
              double dzs = zi - center_coords(k,2);
              double ds2 = (dxs*dxs + dys*dys + dzs*dzs) / (step_mm*step_mm);
              double D = df2 + compact2 * ds2;
              if (D < best) { best = D; bestk = k; }
              k = gindex.next[k];
            }
          }
        }
      }
      labels[i] = bestk;
      dists[i]  = best;
    }
  }
};

// Utility: squared average center shift
double centers_shift2(const NumericMatrix &a, const NumericMatrix &b) {
  int nrow = a.nrow(), ncol = a.ncol();
  double acc = 0.0;
  for (int i = 0; i < nrow; ++i)
    for (int j = 0; j < ncol; ++j) {
      double d = a(i,j) - b(i,j);
      acc += d*d;
    }
  return acc / (double)std::max(1, nrow);
}

// Poisson-disk sampling inside a masked set of voxels (greedy dart throwing)
// mask_lin_idx: N linear indices in full grid (0-based).
// radius_mm: desired minimum spacing in mm; we approximate using voxel spacing.
std::vector<int> poisson_seeds(const IntegerVector &mask_lin_idx,
                               const IntegerVector &dims,
                               const NumericVector &voxmm,
                               double radius_mm,
                               int K_target) {
  int N = mask_lin_idx.size();
  if (N == 0) return {};
  // Compute equivalent voxel radius as radius / mean(voxmm)
  double vstep = (voxmm[0] + voxmm[1] + voxmm[2]) / 3.0;
  double rvox = std::max(1.0, radius_mm / std::max(1e-6, vstep));
  // Grid for neighbor checking
  int nx = dims[0], ny = dims[1], nz = dims[2];
  // Hash from linear index to selected
  std::unordered_set<int, IntHash> selected;
  selected.reserve(K_target*2 + 64);

  // Random permutation of candidate indices
  std::vector<int> order(N);
  for (int i=0;i<N;++i) order[i]=i;
  std::mt19937 rng(12345);
  std::shuffle(order.begin(), order.end(), rng);

  // Helper for distance in voxel coords
  auto lin_to_vox = [&](int lin, int &x, int &y, int &z){
    lin_to_ijk(lin, dims, x,y,z);
  };

  std::vector<std::array<int,3>> selected_coords;
  selected_coords.reserve(K_target*2+64);

  for (int idx : order) {
    int lin = mask_lin_idx[idx];
    int x,y,z; lin_to_vox(lin, x,y,z);
    bool ok = true;
    for (auto &sc : selected_coords) {
      double dx = (double)x - sc[0];
      double dy = (double)y - sc[1];
      double dz = (double)z - sc[2];
      double d2 = dx*dx + dy*dy + dz*dz;
      if (d2 < rvox*rvox) { ok = false; break; }
    }
    if (ok) {
      selected_coords.push_back({x,y,z});
      selected.insert(lin);
      if ((int)selected_coords.size() >= K_target) break;
    }
  }

  // Convert selected linear indices back to masked indices
  std::unordered_map<int,int, IntHash> lin2mask;
  lin2mask.reserve(N*1.3+64);
  for (int i=0;i<N;++i) lin2mask[mask_lin_idx[i]] = i;

  std::vector<int> seeds;
  seeds.reserve(selected.size());
  for (auto &sc : selected_coords) {
    int lin = ijk_to_lin(sc[0], sc[1], sc[2], dims);
    auto it = lin2mask.find(lin);
    if (it != lin2mask.end()) seeds.push_back(it->second);
  }
  return seeds;
}

// Connectivity BFS enforcing one connected component per label
void enforce_strict_connectivity(IntegerVector &labels,
                                 const IntegerVector &mask_lin_idx,
                                 const IntegerVector &dims,
                                 const std::vector<std::array<int,3>> &offsets) {
  int N = labels.size();
  // Map: global linear -> masked idx
  std::unordered_map<int,int, IntHash> idxmap;
  idxmap.reserve(N*1.3+64);
  for (int i=0;i<N;++i) idxmap[ mask_lin_idx[i] ] = i;

  std::vector<char> visited(N, 0);
  IntegerVector new_labels = clone(labels);

  // Track largest component per original label
  std::unordered_map<int, int> largest_comp_size;
  std::unordered_map<int, int> largest_comp_id;  // component id

  int comp_counter = 0;
  std::vector<int> comp_label; comp_label.reserve(N);
  std::vector<int> comp_size;  comp_size.reserve(N);

  // Pass 1: find all components
  for (int i=0;i<N;++i) {
    if (visited[i]) continue;
    int lab = labels[i];
    // BFS
    std::vector<int> queue; queue.reserve(1024);
    queue.push_back(i);
    visited[i]=1;
    int qh=0;
    int size=0;
    while (qh < (int)queue.size()) {
      int u = queue[qh++];
      ++size;
      int lin = mask_lin_idx[u];
      int x,y,z; lin_to_ijk(lin, dims, x,y,z);
      for (auto &d : offsets) {
        int nx = x + d[0], ny = y + d[1], nz = z + d[2];
        if (nx<0 || ny<0 || nz<0 || nx>=dims[0] || ny>=dims[1] || nz>=dims[2]) continue;
        int nlin = ijk_to_lin(nx,ny,nz,dims);
        auto it = idxmap.find(nlin);
        if (it==idxmap.end()) continue;
        int v = it->second;
        if (!visited[v] && labels[v]==lab) { visited[v]=1; queue.push_back(v); }
      }
    }
    comp_label.push_back(lab);
    comp_size.push_back(size);
    // Track largest per label
    auto itL = largest_comp_size.find(lab);
    if (itL == largest_comp_size.end() || size > itL->second) {
      largest_comp_size[lab] = size;
      largest_comp_id[lab] = comp_counter;
    }
    // Mark temp component ID by reusing labels array negative encoding is messy; skip.
    // We'll re-run BFS in pass 2 to modify small components.
    comp_counter++;
  }

  // Reset visited for second pass
  std::fill(visited.begin(), visited.end(), 0);
  int comp_id = 0;
  for (int i=0;i<N;++i) {
    if (visited[i]) continue;
    int lab = labels[i];
    // BFS collect this component
    std::vector<int> comp; comp.reserve(256);
    std::vector<int> boundary_neighbors; boundary_neighbors.reserve(256);
    std::unordered_map<int,int> boundary_counts; boundary_counts.reserve(32);
    std::vector<int> queue; queue.push_back(i); visited[i]=1;
    int qh=0;
    while (qh < (int)queue.size()) {
      int u = queue[qh++];
      comp.push_back(u);
      int lin = mask_lin_idx[u];
      int x,y,z; lin_to_ijk(lin, dims, x,y,z);
      for (auto &d : offsets) {
        int nx = x + d[0], ny = y + d[1], nz = z + d[2];
        if (nx<0 || ny<0 || nz<0 || nx>=dims[0] || ny>=dims[1] || nz>=dims[2]) continue;
        int nlin = ijk_to_lin(nx,ny,nz,dims);
        auto it = idxmap.find(nlin);
        if (it==idxmap.end()) continue;
        int v = it->second;
        if (!visited[v] && labels[v]==lab) { visited[v]=1; queue.push_back(v); }
        else if (labels[v] != lab) {
          boundary_counts[ labels[v] ]++;
        }
      }
    }
    // Keep if this is the largest component for lab; otherwise merge to best neighbor
    bool keep = (comp_size[comp_id] == largest_comp_size[lab]);
    if (!keep) {
      // choose neighbor label with max boundary count
      int bestLab = lab;
      int bestCnt = -1;
      for (auto &kv : boundary_counts) {
        if (kv.second > bestCnt) { bestCnt = kv.second; bestLab = kv.first; }
      }
      if (bestCnt < 0) {
        // no boundary neighbors (isolated island) -> choose arbitrary neighbor by nearest label id +/-
        // but usually won't happen; keep lab to avoid losing label.
      } else {
        for (int u : comp) new_labels[u] = bestLab;
      }
    }
    comp_id++;
  }

  labels = new_labels;
}

// Seeding helpers ------------------------------------------------------------

// Grid in bbox snapped into mask + farthest fill to reach K
std::vector<int> seed_mask_grid(const NumericMatrix &coords,
                                const IntegerVector &mask_lin_idx,
                                int K,
                                double step_mm,
                                const IntegerVector &dims) {
  int N = coords.nrow();
  if (N==0) return {};

  // Build bbox
  double minx = coords(0,0), maxx = coords(0,0);
  double miny = coords(0,1), maxy = coords(0,1);
  double minz = coords(0,2), maxz = coords(0,2);
  for (int i = 1; i < N; ++i) {
    minx = std::min(minx, coords(i,0)); maxx = std::max(maxx, coords(i,0));
    miny = std::min(miny, coords(i,1)); maxy = std::max(maxy, coords(i,1));
    minz = std::min(minz, coords(i,2)); maxz = std::max(maxz, coords(i,2));
  }
  // Voxel cell index by nearest neighbor in coords: Use kd-less approach: brute force in a few neighbor cells
  // We'll simply snap each grid point to nearest masked voxel via linear scan over a small random subset for speed.
  int nx = std::max(1, (int)std::round((maxx-minx)/step_mm));
  int ny = std::max(1, (int)std::round((maxy-miny)/step_mm));
  int nz = std::max(1, (int)std::round((maxz-minz)/step_mm));
  std::vector<int> seed_idx;
  seed_idx.reserve((size_t)nx*ny*nz + 1);

  // Random subset for snapping
  std::vector<int> all(N);
  for (int i=0;i<N;++i) all[i]=i;
  std::mt19937 rng(123);
  std::shuffle(all.begin(), all.end(), rng);

  for (int iz=0; iz<nz; ++iz) for (int iy=0; iy<ny; ++iy) for (int ix=0; ix<nx; ++ix) {
    double gx = minx + (ix + 0.5) * ((maxx-minx)/nx);
    double gy = miny + (iy + 0.5) * ((maxy-miny)/ny);
    double gz = minz + (iz + 0.5) * ((maxz-minz)/nz);
    double best = std::numeric_limits<double>::infinity();
    int besti = -1;
    // check only first ~4096 from shuffled list
    int L = std::min(N, 4096);
    for (int t=0; t<L; ++t) {
      int i = all[t];
      double dx = coords(i,0)-gx, dy = coords(i,1)-gy, dz = coords(i,2)-gz;
      double d2 = dx*dx + dy*dy + dz*dz;
      if (d2 < best) { best = d2; besti = i; }
    }
    if (besti>=0) seed_idx.push_back(besti);
  }

  // Deduplicate and trim/extend to K
  std::sort(seed_idx.begin(), seed_idx.end());
  seed_idx.erase(std::unique(seed_idx.begin(), seed_idx.end()), seed_idx.end());
  if ((int)seed_idx.size() > K) seed_idx.resize(K);
  if ((int)seed_idx.size() < K) {
    // Farthest fill among masked voxels
    std::vector<char> chosen(N, 0);
    for (int id : seed_idx) chosen[id]=1;
    while ((int)seed_idx.size() < K) {
      int besti = -1; double bestd = -1.0;
      for (int trial=0; trial<std::min(N, 8192); ++trial) {
        int i = all[trial % N];
        if (chosen[i]) continue;
        double mind = std::numeric_limits<double>::infinity();
        for (int id : seed_idx) {
          double dx = coords(i,0)-coords(id,0);
          double dy = coords(i,1)-coords(id,1);
          double dz = coords(i,2)-coords(id,2);
          double d2 = dx*dx + dy*dy + dz*dz;
          if (d2 < mind) mind = d2;
        }
        if (mind > bestd) { bestd = mind; besti = i; }
      }
      if (besti>=0) { seed_idx.push_back(besti); chosen[besti]=1; } else break;
    }
  }
  return seed_idx;
}

// Relocate seeds to minimum gradient within a cube of radius r voxels
void relocate_seeds_by_gradient(std::vector<int> &seed_idx,
                                const IntegerVector &mask_lin_idx,
                                const IntegerVector &dims,
                                const std::unordered_map<int,int, IntHash> &lin2mask,
                                const NumericVector &grad_masked,
                                int radius) {
  if (grad_masked.size()==0 || radius<=0) return;
  int nx=dims[0], ny=dims[1], nz=dims[2];
  for (size_t s=0; s<seed_idx.size(); ++s) {
    int mi = seed_idx[s];
    int lin = mask_lin_idx[mi];
    int x,y,z; lin_to_ijk(lin, dims, x,y,z);
    double bestg = grad_masked[mi];
    int best_mi = mi;
    for (int dz=-radius; dz<=radius; ++dz) {
      int zz = z + dz; if (zz<0 || zz>=nz) continue;
      for (int dy=-radius; dy<=radius; ++dy) {
        int yy = y + dy; if (yy<0 || yy>=ny) continue;
        for (int dx=-radius; dx<=radius; ++dx) {
          int xx = x + dx; if (xx<0 || xx>=nx) continue;
          int nlin = ijk_to_lin(xx,yy,zz,dims);
          auto it = lin2mask.find(nlin);
          if (it==lin2mask.end()) continue;
          int nmi = it->second;
          double g = grad_masked[nmi];
          if (g < bestg) { bestg=g; best_mi = nmi; }
        }
      }
    }
    seed_idx[s] = best_mi;
  }
}

//' Core 4D SLIC implementation (C++)
//' @param feats NumericMatrix N x F
//' @param coords NumericMatrix N x 3 (mm)
//' @param mask_lin_idx IntegerVector length N (0-based linear indices in full volume)
//' @param dims IntegerVector length 3: (X,Y,Z)
//' @param voxmm NumericVector length 3: voxel size (mm) for (X,Y,Z)
//' @param K integer
//' @param compactness double
//' @param max_iter int
//' @param step_mm double
//' @param n_threads int
//' @param seed_method string
//' @param enforce_connectivity bool
//' @param min_size int
//' @param connectivity int (6 or 26)
//' @param strict_connectivity bool
//' @param grad_masked NumericVector length N (optional; can be empty)
//' @param seed_relocate_radius int (voxels)
//' @param verbose bool
//'
//' @return list with labels, center_feats, center_coords
// [[Rcpp::export]]
Rcpp::List slic4d_core(NumericMatrix feats,
                       NumericMatrix coords,
                       IntegerVector mask_lin_idx,
                       IntegerVector dims,
                       NumericVector voxmm,
                       int K,
                       double compactness = 10.0,
                       int max_iter = 10,
                       double step_mm = 0.0,
                       int n_threads = 0,
                       std::string seed_method = "mask_grid",
                       bool enforce_connectivity = true,
                       int min_size = 0,
                       int connectivity = 26,
                       bool strict_connectivity = true,
                       NumericVector grad_masked = NumericVector(),
                       int seed_relocate_radius = 1,
                       bool verbose = false) {

  const int N = feats.nrow();
  const int F = feats.ncol();
  if (K < 2 || K > N) stop("K must be in [2, N]");
  if (N < 2) stop("Need at least 2 voxels");
  if (n_threads > 0) {
    RcppParallel::setThreadOptions(n_threads);
  }

  // Compute step if not provided
  double minx = coords(0,0), maxx = coords(0,0);
  double miny = coords(0,1), maxy = coords(0,1);
  double minz = coords(0,2), maxz = coords(0,2);
  for (int i = 1; i < N; ++i) {
    minx = std::min(minx, coords(i,0)); maxx = std::max(maxx, coords(i,0));
    miny = std::min(miny, coords(i,1)); maxy = std::max(maxy, coords(i,1));
    minz = std::min(minz, coords(i,2)); maxz = std::max(maxz, coords(i,2));
  }
  double dx = std::max(1e-6, maxx - minx);
  double dy = std::max(1e-6, maxy - miny);
  double dz = std::max(1e-6, maxz - minz);
  double vol = dx * dy * dz;
  if (step_mm <= 0.0) step_mm = std::cbrt(vol / (double)K);

  // --- Seed initialization ---
  std::vector<int> seed_idx;
  if (seed_method == "mask_poisson") {
    seed_idx = poisson_seeds(mask_lin_idx, dims, voxmm, step_mm, K);
    if ((int)seed_idx.size() < K) {
      // top up with mask_grid
      auto extra = seed_mask_grid(coords, mask_lin_idx, K - seed_idx.size(), step_mm, dims);
      seed_idx.insert(seed_idx.end(), extra.begin(), extra.end());
      // dedup
      std::sort(seed_idx.begin(), seed_idx.end());
      seed_idx.erase(std::unique(seed_idx.begin(), seed_idx.end()), seed_idx.end());
      if ((int)seed_idx.size() > K) seed_idx.resize(K);
    }
  } else if (seed_method == "grid" || seed_method == "mask_grid" || seed_method == "farthest") {
    seed_idx = seed_mask_grid(coords, mask_lin_idx, K, step_mm, dims);
  } else {
    stop("Unknown seed_method");
  }

  // Build linear -> masked map for relocation
  std::unordered_map<int,int, IntHash> lin2mask;
  lin2mask.reserve(N*1.3 + 64);
  for (int i=0;i<N;++i) lin2mask[ mask_lin_idx[i] ] = i;

  // Optional gradient-based relocation
  if (grad_masked.size() == N && seed_relocate_radius > 0) {
    relocate_seeds_by_gradient(seed_idx, mask_lin_idx, dims, lin2mask, grad_masked, seed_relocate_radius);
  }

  // Initialize centers from seeds
  NumericMatrix center_feats(K, F);
  NumericMatrix center_coords(K, 3);
  for (int k = 0; k < K; ++k) {
    int idx = seed_idx[k % seed_idx.size()];
    for (int f = 0; f < F; ++f) center_feats(k,f) = feats(idx, f);
    center_coords(k,0) = coords(idx,0);
    center_coords(k,1) = coords(idx,1);
    center_coords(k,2) = coords(idx,2);
  }

  // Build grid index for centers: cell size ~ 2*step_mm
  double cellStep = 2.0 * step_mm;
  int cnx = std::max(1, (int)std::floor(dx / cellStep));
  int cny = std::max(1, (int)std::floor(dy / cellStep));
  int cnz = std::max(1, (int)std::floor(dz / cellStep));
  GridIndex gindex(cnx, cny, cnz, cellStep, center_coords, NumericVector::create(minx,miny,minz));
  gindex.first.assign(cnx*cny*cnz, -1);
  gindex.next.assign(K, -1);
  for (int k = 0; k < K; ++k) {
    int cell = gindex.cell_of_center(k);
    gindex.next[k] = gindex.first[cell];
    gindex.first[cell] = k;
  }

  // Initialize labels and dists
  IntegerVector labels(N);
  NumericVector dists(N);
  for (int i = 0; i < N; ++i) { labels[i] = 0; dists[i] = std::numeric_limits<double>::infinity(); }

  // Iterate
  NumericMatrix prev_center_coords = clone(center_coords);
  NumericMatrix prev_center_feats  = clone(center_feats);
  for (int it = 0; it < max_iter; ++it) {
    AssignWorker worker(feats, coords, center_feats, center_coords, gindex, compactness, step_mm, labels, dists);
    parallelFor(0, (size_t)N, worker, 2000);

    // Update centers
    std::vector<double> sumf((size_t)K * F, 0.0);
    std::vector<double> sumx(K, 0.0), sumy(K, 0.0), sumz(K, 0.0);
    std::vector<int>    cnt(K, 0);
    for (int i = 0; i < N; ++i) {
      int k = labels[i];
      cnt[k]++;
      for (int f = 0; f < F; ++f) sumf[(size_t)k * F + f] += feats(i,f);
      sumx[k] += coords(i,0);
      sumy[k] += coords(i,1);
      sumz[k] += coords(i,2);
    }
    for (int k = 0; k < K; ++k) {
      double c = std::max(1, cnt[k]);
      for (int f = 0; f < F; ++f) center_feats(k,f) = sumf[(size_t)k * F + f] / c;
      center_coords(k,0) = sumx[k] / c;
      center_coords(k,1) = sumy[k] / c;
      center_coords(k,2) = sumz[k] / c;
    }

    // Rebuild center grid index
    std::fill(gindex.first.begin(), gindex.first.end(), -1);
    for (int k = 0; k < K; ++k) {
      int cell = gindex.cell_of_center(k);
      gindex.next[k] = gindex.first[cell];
      gindex.first[cell] = k;
    }

    double shift_c = centers_shift2(center_coords, prev_center_coords);
    double shift_f = centers_shift2(center_feats,  prev_center_feats);
    if (verbose) Rcpp::Rcout << "iter " << it+1 << " shift_coords=" << std::sqrt(shift_c)
                             << " shift_feats=" << std::sqrt(shift_f) << std::endl;
    prev_center_coords = clone(center_coords);
    prev_center_feats  = clone(center_feats);
    if (shift_c + shift_f < 1e-6) break;
  }

  if (enforce_connectivity) {
    std::vector<std::array<int,3>> offsets = (connectivity == 6) ? make_offsets6() : make_offsets26();
    enforce_strict_connectivity(labels, mask_lin_idx, dims, offsets);
  }

  // Normalize labels to 1..K (some labels may become empty; reindex for compactness)
  // Map old label -> new label
  std::vector<int> uniq(K, 0);
  for (int i=0;i<N;++i) uniq[ labels[i] ] = 1;
  std::vector<int> maplab(K, -1);
  int cur=0;
  for (int k=0;k<K;++k) if (uniq[k]) maplab[k]=cur++;
  for (int i=0;i<N;++i) labels[i] = maplab[ labels[i] ] + 1; // 1-based for R

  return List::create(
    _["labels"] = labels,
    _["center_feats"] = center_feats,
    _["center_coords"] = center_coords
  );
}
